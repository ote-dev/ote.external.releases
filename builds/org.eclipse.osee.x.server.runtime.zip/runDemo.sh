java -server \
-Xmx1024m \
-Dorg.osgi.service.http.port=8089 \
-Dorg.eclipse.equinox.http.jetty.context.sessioninactiveinterval=3600 \
-Dcm.config.uri="etc/osee.hsql.json" \
-Dosee.authentication.protocol=demo \
-Dosee.application.server.data="demo/binary_data" \
-jar plugins/org.eclipse.equinox.launcher_1.3.100.v20150511-1540.jar -console -consoleLog
